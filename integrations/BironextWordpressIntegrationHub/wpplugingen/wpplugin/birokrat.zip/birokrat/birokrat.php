<?php

/**
 * Plugin Name: Birokrat plugin
 * Plugin URI: https://woocommerce.com/
 * Description: The official Birokrat integration plugin.
 * Version: 0.0.1
 * Author: Kristijan Mirceta
 * Author URI: https://woocommerce.com
 * Text Domain: woocommerce
 * Domain Path: /i18n/languages/
 * Requires at least: 5.4
 * Requires PHP: 7.0
 *
 * @package Birokrat
 */

// don't call the file directly
defined( 'ABSPATH' ) or die( 'Nope, not accessing this' );

/**
 * Check if WooCommerce is active
 **/
if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) { exit; }
   
require_once('includes/utils.php');
require_once('includes/wooserialization.php');
require_once('includes/bironextclient.php');


class BirokratPlugin {
	private static $birokrat;
	
	private function __construct() {
		$this->constants(); // Defines any constants used in the plugin
		$this->init();   // Sets up all the actions and filters
	}
	
	public static function getInstance() {
		if ( !self::$birokrat ) {
			self::$birokrat = new BirokratPlugin();
		}

		return self::$birokrat;
	}

	private function constants() {
		
	}

	private function init() {
		$opts = array();
		$opts['wporg_field_bironext_api_key'] = '7iHtJntGJO8rpzrgRHfn+IbF07jRWdY94wm3ndamjI8=';
		$opts['wporg_field_bironext_address'] = 'http://next2.birokrat.si/';
		$option_name = 'wporg_options';
		
		
		logInformation('ERROR ON ADD OPTION', array($opts), 'WP_EVENTS');	
		
		if (!get_option($option_name, false)) {
			if (!add_option($option_name, $opts)) {
				logInformation('ERROR ON ADD OPTION', array($opts), 'WP_EVENTS');	
			}
			
		} else {
			if (!update_option($option_name, $opts)) {
				logInformation('ERROR ON UPDATE OPTION', array($opts), 'WP_EVENTS');
			}
		}
		add_action( 'woocommerce_order_status_processing', array($this, 'onOrderStatusChanged'));
		add_action( 'woocommerce_order_status_on-hold', array($this, 'onOrderStatusChanged'));
		//add_filter( 'woocommerce_email_attachments', array($this, 'onEmailIntercepted'), 10, 3);
	}	
	
	
	// #region [EVENTS]
	function onTurnOnSyncProducts() {
		
	}

	function onEmailIntercepted($attachments, $email_id, $order) {
		// Avoiding errors and problems
		if ( ! is_a( $order, 'WC_Order' ) || ! isset( $email_id ) ) {
			return $attachments;
		}
		
		$json = create_serializable_order($order);
		$response = sendHttpPostRequest('main/on-attachment-request', json_encode($json));
		
		
		$base64data = base64_decode($response, false);
		$upload_dir   = wp_upload_dir(); 
		if ( ! empty( $upload_dir['basedir'] ) ) {
		    $user_dirname = $upload_dir['basedir'].'/invoice.pdf';
		    file_put_contents($user_dirname, $base64data);
			$attachments[] = $user_dirname;
		} else {
			$response = sendHttpPostRequest('main/ping', '');
		}
		
		logInformation('EMAIL RESPONSE', array($response), 'L1');
		return $attachments;
	}
	
	function onProductAdded($post_id) {
		$response = sendHttpPostRequest('main/on-article-added-raw', json_encode($post_id));
	}
	
	function onProductChanged($post_id) {
		$response = sendHttpPostRequest('main/on-article-changed-raw', json_encode($post_id));
	}
	
	function onProductDeleted($product) {
		
	}
	
	function onOrderStatusChanged( $arg1 ) {
		logInformation('on order status changed', array(), '');
		$order = wc_get_order($arg1);
		$json = create_serializable_order($order);
		$response = sendHttpPostRequest('main/on-order-status-changed', json_encode($json));
	}
	// #endregion
	
	////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////
	// WORDPRESS EVENT SETUP
	
	// article
	// before woocommerce 3.0
	
	
	function wpse_110037_new_posts($new_status, $old_status, $post) {
	 	logInformation('POSTS EVENT', array(), '');
		if (!empty($post->ID) && in_array( $post->post_type, array( 'product') )) {
			if ($old_status != 'publish' && $new_status == 'publish') {
				onAddNewProduct($post->ID);		
			} else if ($new_status == 'trash') {
				// on delete
			} 
			else {
				if (!(in_array($old_status, array('new', 'auto-draft')) || in_array($new_status, array('new', 'auto-draft')))) {
					afterModifyExistingProduct($post->ID);
				}
				else {
					// new post draft
				}
			}
		}
			
	}
	
	function onAddNewProduct($post_id) {
		/* Optional full data
		logInformation('on Add new product', array(), '');
		$product = wc_get_product( $post_id );
		onProductAdded($product);
		*/
	}
	
	function afterModifyExistingProduct($post_id) {
		/* Optional full data
		logInformation('modify existing product', array(), '');
		$old_product_data = get_option('last_edited_product2');
		$new_product = wc_get_product($post_id);
		onProductChanged($old_product_data, $new_product);
		*/
	}
	
	function beforeOperationOnProduct($post_id, $data) {
		logInformation('before operation on product', array(), '');
		$post_type = $data->post_type;
		if (!$post_type) {
			$post_type = $data['post_type'];
		}
		
		if ($post_type == 'product') {
				
			$original = wc_get_product( $post_id );
			$product = deep_copy($original->get_data());
			//$product['post_id'] = $post_id;
			
			$option_name = 'last_edited_product2';
			
			if (!get_option($option_name, false)) {
				if (!add_option($option_name, $product)) {
					logInformation('ERROR ON ADD OPTION', array($product), 'WP_EVENTS');	
				}
				
			} else {
				if (!update_option($option_name, $product)) {
					logInformation('ERROR ON UPDATE OPTION', array($product), 'WP_EVENTS');
				}
			}
			logInformation('PREUPDATE', array($product['name'], get_option($option_name)), 'WP_EVENTS');
		}
		else if ($post_type == 'shop_order') {
			// set up perhaps for future use
		}
	}
}
$birokrat = BirokratPlugin::getInstance();